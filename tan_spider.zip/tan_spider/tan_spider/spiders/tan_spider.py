 #coding=gbk
'''
Created on Jun 23, 2016

@author: chenbinbin
'''
import os
import scrapy
from scrapy.spiders.crawl import CrawlSpider
from lxml.html import open_in_browser
from setuptools.sandbox import override_temp
from scrapy.selector import Selector
from pip._vendor.requests.models import Response
from scrapy.http.request import Request
from scrapy.http import FormRequest
from selenium import webdriver
from Carbon.QuickDraw import frame

class data1_struct(scrapy.Item):
    data_type = scrapy.Field()
    genomic = scrapy.Field()
    cDNA = scrapy.Field()
    Exon = scrapy.Field()
    Protein = scrapy.Field()
    Functional_domain = scrapy.Field()
    Biological_significance = scrapy.Field()
    Validated_by = scrapy.Field()
    Date = scrapy.Field()
    Records = scrapy.Field()

class tan_business(scrapy.Spider):
    name = "tan_business"
    start_urls = ['http://www.umd.be/BRCA2/']
    
    def __init__(self):
        scrapy.Spider.__init__(self)
        self.browser = webdriver.Firefox()
        pass
    
    def __del__(self):
        self.browser.close()
        pass
    
    def parse(self, response):    
        self.browser.get(response.url)
        frame1 = self.browser.find_element_by_name("indexL1")        
        self.browser.switch_to_frame(frame1)
        buttons = self.browser.find_elements_by_class_name("menu_bouton")
        if len(buttons) == 0:
            pass
        
        mutations_button = buttons[0]
        
        for button in buttons:
            if button.text == "Mutations":
                mutations_button = button
                break  
        
        mutations_button.click()
        
        
        self.browser.switch_to_default_content()
        frame2 = self.browser.find_element_by_name("indexR.shtml")
        self.browser.switch_to_frame(frame2)
        
        login_buttons = self.browser.find_elements_by_id("submit_button")
        for button in login_buttons:
            if button.text == "Login":
                button.click()
                break
        try:
            email_edit = self.browser.find_element_by_id("email")
            pwd_edit = self.browser.find_element_by_id("pwd")
            email_edit.send_keys("tanmeihua12@mails.ucas.ac.cn")
            pwd_edit.send_keys("987654321poiuy")
            login_click = self.browser.find_element_by_id("submit_button")
            login_click.click()
        except:
            pass        
        self.browser.switch_to_default_content()
        self.browser.switch_to_frame(frame1)
        mutations_button.click()
        
        self.browser.switch_to_default_content()
        self.browser.switch_to_frame(frame2)
        
        total_button = self.browser.find_elements_by_xpath('//table[@class="cftr"]/tbody/tr/td[@class="cftr"]/table/tbody/tr/td/div/a')[0]
        total_button_url = total_button.get_attribute("href")
        self.browser.get(total_button_url)
        
        count_log = self.browser.find_elements_by_xpath('//div[@id="pagermutationsGrid"]/div/div')[2]
        total_count = int(count_log.text.split(" ")[-1])
        
        loop_cout = 0
        if total_count % 10 == 0 :
            loop_count = int(total_count) / 10
        else:
            loop_count = int(total_count) / 10 + 1
            
        next_click = count_log = self.browser.find_elements_by_xpath('//div[@id="pagermutationsGrid"]/div/div')[0]
        data1_list = []
        
        for i in range(0, loop_count):
            for j in range(0, 9):
                id_format = "row%dmutationsGrid" % j
                data_tmp_row = self.browser.find_element_by_id(id_format)
                if len(data_tmp_row.text.split("\n")) != 9:
                    xpath_format = '//div[@id="row%dmutationsGrid"]/div' % j
                    data1_row = self.browser.find_elements_by_xpath(xpath_format)
                    data_line = ""
                    for t in range(0, len(data1_row)):
                        per_line = data1_row[t].text
                        if per_line == "":
                            per_line = "-"
                        data_line += per_line + "\n"
                    data1_list.append(data_line)
                else:
                    data1_list.append(data_tmp_row.text)
            next_click.click()
            
        # collect data1
        for data1 in data1_list:
            data1_item = data1_struct()
            tmp_list = data1.split("\n")    
            data1_item['data_type'] = "data1_flag"
            data1_item['genomic'] = tmp_list[0]
            data1_item['cDNA'] = tmp_list[1]
            data1_item['Exon'] = tmp_list[2]
            data1_item['Protein'] = tmp_list[3]
            data1_item['Functional_domain'] = tmp_list[4]
            data1_item['Biological_significance'] = tmp_list[5]
            data1_item['Validated_by'] = tmp_list[6]
            data1_item['Date'] = tmp_list[7]
            data1_item['Records'] = tmp_list[8]     
            yield data1_item
            
        pass
        
    def after_login(self, response):
        # check login succeed before going on
        pass
        
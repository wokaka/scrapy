# -*- coding: utf-8 -*-
from Finder.Finder_items import item
from scrapy.item import Item

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


class TanSpiderPipeline(object):
    def process_item(self, item, spider):
        if item['data_type'] != "data1_flag":
            return item
    
        data1_file_name = "/Users/chenbinbin/Desktop/data1_list.txt"
        file = open(data1_file_name, "a")
        file.write(item["genomic"] + "|" + item["cDNA"] + "|" + item["Exon"] + "|" + \
                   item["Protein"] + "|" + item["Functional_domain"] + item["Biological_significance"] + "|" + \
                   item["Validated_by"] + "|" + item["Date"] + "|" + item["Records"] + "\n")
        
        file.close()
        return item

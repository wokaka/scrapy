'''
Created on Jun 18, 2016

@author: chenbinbin
'''
import os
import MySQLdb
from scrapy import cmdline



if __name__ == '__main__':
    #cmdline.execute("scrapy crawl similar_company -a company_name=TCL -a similar_depth=1 -a max_page=50".split())   
    cmdline.execute("scrapy crawl tan_business".split())
    #mysql_test()
    #pathtest()
    pass
 
